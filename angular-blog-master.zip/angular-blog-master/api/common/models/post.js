'use strict';

module.exports = function(Post) {

};
