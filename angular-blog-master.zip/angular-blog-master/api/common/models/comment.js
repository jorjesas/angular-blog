'use strict';

module.exports = function(Comment) {

};
