'use strict';

module.exports = function(Account) {

};
