export class Comment{

  constructor(
    public name?: string,
    public title?: string,
    public body?: string,
    public postId?: string,

  ){


  }
}
